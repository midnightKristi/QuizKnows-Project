<?php
//Credit: Steven: based off of navbar
?>
<link rel="stylesheet" href="<?php echo get_url('static/main.css'); ?>">
<div class="topNav"div>
    <a class="active" href="/flashcards/pages/index.php">Exit Admin Area</a>
    <a class="active" href="/flashcards/pages/Admin/Search/adminSearch.php">Search</a>
    <a class="active" href="/flashcards/pages/Admin/Card/adminDeleteCard.php">Cards</a>
    <a class="active" href="/flashcards/pages/Admin/User/adminDeleteUser.php">Users</a>
    <a class="active" href="/flashcards/pages/Admin/Subject/adminDeleteSubject.php">Subjects</a>
    <a class="active" href="/flashcards/pages/logOut.php">Logout</a>
</div>

