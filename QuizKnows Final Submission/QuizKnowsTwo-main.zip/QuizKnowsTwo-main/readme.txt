QuizKnows is a web based flashcard application assignment for CSCIU521. Property of Aaron, Gillian, Steven, and Kristi. CODE IS NOT FOR OTHERS USE WITHOUT PERMISSION. FINES WILL BE CHARGED BASED ON UNAUTHORIZED UTILIZATION!
Steps to make work:

1) Upload files into HTDOCS in XAMPP (Download if necessary).
2) Make table flashcards and run table located in flashcards docs folder. 
3) Launch XAMPP and turn on Apache and MYSQL. 
4) Go to the main index page of localhost/flashcards/pages/index.php. 
5) Enjoy

Features: 

Create Subject:

List- show all subjects.
Create - create subjects using Subject Name.
Read - read using Subject ID.
Update - update by SubjectID and Subject Name.
Delete - delete by Subject ID.
Show set of cards - shows a set of cards all in the table. 

Create Card:

List- Show all cards
Create- Create Card (SubjectID, Question, Answer)
Delete- Delete card using Card ID
Update - Update card (CardID, SubjectID, Question, Answer)
Show Set of Cards- Shows set of cards (uses subject_ID in search to work) 

Admin Page:

Able to edit, delete users, subjects, and  cards. 

Login, Logout, Register features. 

Learn:

Fill in the blank 
Study
Matching

MIT LICENSE GIVEN UPON REQUEST
