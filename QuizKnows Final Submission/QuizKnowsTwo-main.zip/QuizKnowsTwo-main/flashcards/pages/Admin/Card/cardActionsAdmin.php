<?php
//Credit Aaron based off navbar
?>
<div class="navbar">
    <ul>
        <li><a href="<?php echo get_url('pages/Admin/Card/adminEditCard.php'); ?>">Update</a></li>
        <li><a href="<?php echo get_url('pages/Admin/Card/adminDeleteCard.php'); ?>">Delete</a></li>
        <li><a href="<?php echo get_url('pages/Admin/Search/adminSearch.php'); ?>">Search</a></li>
    </ul>
</div>
