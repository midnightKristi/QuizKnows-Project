<!--BEGIN HEADER-->
<html>
<head>
	<title>QuizKnows</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
	<div id="wrapper">
		<div id="banner">		
			<h1>flashcard<span class="accent">ELITE</span></h1>
		</div>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="new_card.php">New Flash Card</a></li>
			</ul>
		</nav>
		<div id="content">
<!--END HEADER-->