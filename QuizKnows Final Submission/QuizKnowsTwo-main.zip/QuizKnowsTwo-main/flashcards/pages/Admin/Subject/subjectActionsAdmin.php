<?php
//Credit Aaron based off navbar
?>
<div class="navbar">
    <ul>
        <li><a href="<?php echo get_url('pages/Admin/Subject/adminEditSubject.php'); ?>">Update</a></li>
        <li><a href="<?php echo get_url('pages/Admin/Subject/adminDeleteSubject.php'); ?>">Delete</a></li>
        <li><a href="<?php echo get_url('pages/Admin/Search/adminSearch.php'); ?>">Search</a></li>
    </ul>
</div>
