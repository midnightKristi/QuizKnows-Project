<html>
<body>
<footer>
<p>Quizknows&copy</p>
</footer>
</body>
</html>