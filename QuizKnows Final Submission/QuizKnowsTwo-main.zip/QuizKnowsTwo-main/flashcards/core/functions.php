<?php
// functions used for views
// Created by Aaron Chance Edwards
function get_url($page_name){
    return BASE_URL . '/' . $page_name;
}

?>