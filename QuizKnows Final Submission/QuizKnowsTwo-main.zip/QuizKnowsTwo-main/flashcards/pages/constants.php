<?php
//Credits Aaron
 define("BASE_URL", 'http://localhost/' . APP_FOLDER_NAME);
 define('DB_HOST', 'localhost');
 define('DB_NAME', 'flashcards');
 define('DB_USER', 'root');
 define('DB_PASS','');
?>